import tkinter as tk
from tkinter import ttk  # Import ttk from tkinter

import json

def populate_tree(tree, node):
    if isinstance(node, dict):
        for key, value in node.items():
            item = tree.insert("", "end", text=key)
            populate_tree(tree, value)
    elif isinstance(node, list):
        for item in node:
            populate_tree(tree, item)
    else:
        tree.insert("", "end", text=node)

# Load the JSON data from the file
with open("topic.json", "r") as file:
    data = json.load(file)

# Create the main window
root = tk.Tk()
root.title("JSON Tree Visualization")

# Create a Treeview widget
tree = ttk.Treeview(root)  # Use ttk from tkinter
tree.heading("#0", text="JSON Data")
tree.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

# Populate the tree
populate_tree(tree, data)

root.mainloop()
